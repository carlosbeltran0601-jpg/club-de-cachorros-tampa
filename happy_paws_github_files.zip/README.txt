# Happy Paws Website

Upload `index.html` and the entire `assets` folder to your GitHub repository.

Keep this structure:

index.html
assets/
  puppy-blue-bow.jpeg
  golden-puppy.png
  white-puppy.jpeg

The images are already referenced by the HTML, so you do not need to add image URLs manually.

Phone number on the site: 813-499-3860
